# 📱 Android VM on GitHub Codespaces

Run Android x86 inside GitHub Codespaces using QEMU + noVNC.

---

## Option A — One-Command Setup (paste in terminal)

Open your Codespace terminal and run:

```bash
bash scripts/setup-android.sh
```

That's it. The script does everything automatically.

---

## Option B — Auto-Launch on Codespace Start (devcontainer)

The `.devcontainer/` folder is already configured.

1. Push this repo to GitHub
2. Open it in Codespaces
3. Android downloads and starts **automatically**

---

## Accessing Android

1. Go to the **PORTS** tab in VS Code
2. Find port **6080**
3. Right-click → **Port Visibility → Public**
4. Click the 🌐 globe icon
5. Add `/vnc.html` to the URL
6. Click **Connect**

---

## Android Boot Menu Options

- **Android-x86 9.0-r2** → Full install to virtual disk
- **Live CD - Run Android without installing** → Quick test, no install needed

---

## ADB (optional)

Connect to Android from the terminal:

```bash
adb connect localhost:5555
adb devices
adb shell
```

---

## Tips

- First boot takes **2-3 minutes**
- Choose **Live CD** for fastest start
- Keep the terminal open — closing it stops the VM
- Files persist in `android_disk.qcow2` between sessions (if installed)
