#!/bin/bash
# Runs once when Codespace is first created (postCreateCommand)
echo "📦 Installing Android VM dependencies..."

sudo apt-get update -qq
sudo apt-get install -y -qq \
    qemu-system-x86 \
    qemu-utils \
    novnc \
    websockify \
    wget \
    net-tools \
    curl \
    procps \
    adb

echo "📱 Downloading Android-x86 9.0 ISO (~900MB)..."
if [ ! -f "$HOME/android.iso" ]; then
    wget -q --show-progress \
        "https://sourceforge.net/projects/android-x86/files/Release%209.0/android-x86_64-9.0-r2.iso/download" \
        -O "$HOME/android.iso"
fi

echo "💾 Creating virtual disk..."
if [ ! -f "$HOME/android_disk.qcow2" ]; then
    qemu-img create -f qcow2 "$HOME/android_disk.qcow2" 16G
fi

echo "✅ Setup complete! Android VM is ready to start."
