#!/bin/bash
# Runs every time Codespace starts (postStartCommand)
echo "🚀 Starting Android VM..."

# Kill any existing sessions
pkill -f qemu-system-x86_64 2>/dev/null || true
pkill -f websockify 2>/dev/null || true
sleep 1

# Check KVM
if [ -e /dev/kvm ]; then
    KVM_FLAG="-enable-kvm -cpu host"
    echo "✅ KVM available — fast mode"
else
    KVM_FLAG="-cpu max"
    echo "⚠️  No KVM — slow mode (still works)"
fi

# Start QEMU
qemu-system-x86_64 \
    $KVM_FLAG \
    -m 3072 \
    -smp 2 \
    -hda "$HOME/android_disk.qcow2" \
    -cdrom "$HOME/android.iso" \
    -boot order=d \
    -vnc :0,password=off \
    -net nic \
    -net user,hostfwd=tcp::5555-:5555 \
    -vga std \
    -no-reboot \
    -display none \
    2>/tmp/qemu.log &

echo "✅ QEMU started"
sleep 2

# Start noVNC
websockify --web /usr/share/novnc/ 6080 localhost:5900 \
    > /tmp/novnc.log 2>&1 &

echo "✅ noVNC started on port 6080"
echo ""
echo "════════════════════════════════════"
echo "  Android VM is RUNNING!"
echo "  Open port 6080 → add /vnc.html"
echo "════════════════════════════════════"
