#!/bin/bash
# ============================================================
#  Android VM Auto-Setup for GitHub Codespaces
#  Run with: bash setup-android.sh
# ============================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

BOLD='\033[1m'

print_step() {
  echo -e "\n${BLUE}${BOLD}[STEP]${NC} ${CYAN}$1${NC}"
}

print_ok() {
  echo -e "${GREEN}[OK]${NC} $1"
}

print_warn() {
  echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

echo -e "\n${BOLD}${CYAN}"
echo "  █████╗ ███╗   ██╗██████╗ ██████╗  ██████╗ ██╗██████╗     ██╗   ██╗███╗   ███╗"
echo " ██╔══██╗████╗  ██║██╔══██╗██╔══██╗██╔═══██╗██║██╔══██╗    ██║   ██║████╗ ████║"
echo " ███████║██╔██╗ ██║██║  ██║██████╔╝██║   ██║██║██║  ██║    ██║   ██║██╔████╔██║"
echo " ██╔══██║██║╚██╗██║██║  ██║██╔══██╗██║   ██║██║██║  ██║    ╚██╗ ██╔╝██║╚██╔╝██║"
echo " ██║  ██║██║ ╚████║██████╔╝██║  ██║╚██████╔╝██║██████╔╝     ╚████╔╝ ██║ ╚═╝ ██║"
echo " ╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝╚═════╝       ╚═══╝  ╚═╝     ╚═╝"
echo -e "${NC}"
echo -e "${BOLD}         Android x86 VM on GitHub Codespaces — Auto Setup${NC}"
echo -e "         ─────────────────────────────────────────────────\n"

# ── Step 1: System update & install packages ──
print_step "Installing QEMU, noVNC, and dependencies..."
sudo apt-get update -qq
sudo apt-get install -y -qq \
    qemu-system-x86 \
    qemu-utils \
    novnc \
    websockify \
    wget \
    net-tools \
    xdotool \
    curl \
    procps

print_ok "All packages installed."

# ── Step 2: Check KVM ──
print_step "Checking KVM support..."
if [ -e /dev/kvm ]; then
    print_ok "KVM is available! Android will run fast."
    KVM_FLAG="-enable-kvm -cpu host"
else
    print_warn "KVM not available. Running without hardware acceleration (slower but works)."
    KVM_FLAG="-cpu max"
fi

# ── Step 3: Download Android ISO ──
ISO_PATH="$HOME/android.iso"
DISK_PATH="$HOME/android_disk.qcow2"

print_step "Downloading Android-x86 9.0 ISO (~900MB)..."
if [ -f "$ISO_PATH" ]; then
    print_ok "ISO already exists, skipping download."
else
    wget -q --show-progress \
        "https://sourceforge.net/projects/android-x86/files/Release%209.0/android-x86_64-9.0-r2.iso/download" \
        -O "$ISO_PATH"
    print_ok "ISO downloaded."
fi

# ── Step 4: Create virtual disk ──
print_step "Creating 16GB virtual disk..."
if [ -f "$DISK_PATH" ]; then
    print_ok "Disk already exists, skipping."
else
    qemu-img create -f qcow2 "$DISK_PATH" 16G
    print_ok "Virtual disk created."
fi

# ── Step 5: Kill any existing QEMU/noVNC ──
print_step "Cleaning up any previous sessions..."
pkill -f qemu-system-x86_64 2>/dev/null || true
pkill -f websockify 2>/dev/null || true
sleep 2
print_ok "Clean."

# ── Step 6: Start QEMU ──
print_step "Starting Android VM in QEMU..."
qemu-system-x86_64 \
    $KVM_FLAG \
    -m 3072 \
    -smp 2 \
    -hda "$DISK_PATH" \
    -cdrom "$ISO_PATH" \
    -boot order=d \
    -vnc :0,password=off \
    -net nic \
    -net user,hostfwd=tcp::5555-:5555 \
    -vga std \
    -no-reboot \
    -display none \
    2>/tmp/qemu.log &

QEMU_PID=$!
print_ok "QEMU started (PID: $QEMU_PID)"
sleep 3

# Check QEMU actually started
if ! kill -0 $QEMU_PID 2>/dev/null; then
    print_error "QEMU failed to start. Log:"
    cat /tmp/qemu.log
    exit 1
fi

# ── Step 7: Start noVNC ──
print_step "Starting noVNC web interface on port 6080..."
websockify --web /usr/share/novnc/ 6080 localhost:5900 \
    > /tmp/novnc.log 2>&1 &

NOVNC_PID=$!
sleep 2

if ! kill -0 $NOVNC_PID 2>/dev/null; then
    print_error "noVNC failed to start. Log:"
    cat /tmp/novnc.log
    exit 1
fi

print_ok "noVNC started (PID: $NOVNC_PID)"

# ── Step 8: Keep-alive loop ──
echo -e "\n${BOLD}${GREEN}════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}  ✅ Android VM is RUNNING!${NC}"
echo -e "${BOLD}${GREEN}════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${BOLD}  📺 To access Android:${NC}"
echo -e "  1. Go to the ${CYAN}PORTS${NC} tab in VS Code (bottom panel)"
echo -e "  2. Make sure port ${CYAN}6080${NC} is forwarded"
echo -e "  3. Right-click port 6080 → ${CYAN}Port Visibility → Public${NC}"
echo -e "  4. Click the globe icon to open in browser"
echo -e "  5. Add ${CYAN}/vnc.html${NC} to the URL"
echo -e "  6. Click ${CYAN}Connect${NC}"
echo ""
echo -e "${BOLD}  📱 Android Boot Menu:${NC}"
echo -e "  → Select ${CYAN}Android-x86 9.0-r2${NC}"
echo -e "  → Or ${CYAN}Live CD (Run without installing)${NC} for quick test"
echo ""
echo -e "${BOLD}  💾 To install Android permanently:${NC}"
echo -e "  → In boot menu select ${CYAN}Installation${NC}"
echo -e "  → Choose the virtual disk"
echo ""
echo -e "${BOLD}  🔌 ADB connection (optional):${NC}"
echo -e "  → Forward port ${CYAN}5555${NC} and run: ${CYAN}adb connect localhost:5555${NC}"
echo ""
echo -e "${YELLOW}  ⚠️  Keep this terminal open! Closing it stops the VM.${NC}"
echo -e "${BOLD}${GREEN}════════════════════════════════════════════════════${NC}\n"

# Keep script alive and show status
while true; do
    if ! kill -0 $QEMU_PID 2>/dev/null; then
        print_error "QEMU crashed. Check /tmp/qemu.log"
        exit 1
    fi
    sleep 30
    echo -e "${GREEN}[$(date +%H:%M:%S)]${NC} VM running... (QEMU PID: $QEMU_PID)"
done
